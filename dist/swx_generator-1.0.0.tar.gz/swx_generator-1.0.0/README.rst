# SWX-GENERATOR

* Version: 1.0.0

## Dependencies:

Django == 1.7.X+

## Installation:

Add 'swx-generator' to your `INSTALLED_APPS`.

## Avaliable commands:

```sh
python manage.py create_model project name
```

